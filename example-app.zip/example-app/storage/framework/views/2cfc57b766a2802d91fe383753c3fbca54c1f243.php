<!DOCTYPE html>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />


<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link href='https://fonts.googleapis.com/css?family=Playfair Display' rel='stylesheet'>

  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />


  <link rel="stylesheet" href="assets/web_page.css" />



  <link
    rel="shortcut icon"
    href="assets\img\logo.png"
    type="image/x-icon"
  />
  <link
    href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@700&display=swap"
    rel="stylesheet"
  />

  <!-- Font -->
  <link href="https://fonts.googleapis.com/css2?family=Nanum+Pen+Script&display=swap" rel="stylesheet">

  <title>Web Page</title>
</head>


<body>
    <nav class="navbar navbar-expand-lg fixed-top bg-transparant pt-4">
        <div class="container-md">
          <a class="navbar-brand" href=""
            ><img
              src="assets\img\logo.png"
              alt="DigitalArt Games Logo"
              style="width: 80px; height: 80px"
          /></a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item" id="dropdown">
                <a class="nav-link" href="#"><p>services</p></a>
              </li>
              <li class="nav-item" id="dropdown2">
                <a class="nav-link" href="#"><p>project</p></a>
              </li>
              <li class="nav-item" id="dropdown2">
                <a class="nav-link" href="#"><p>project</p></a>
              </li>
              <div class="dot"></div>
            </ul>
          </div>
        </div>
      </nav>


      <div
        class="big-menu d-none">

        <div>




  <?php echo $__env->yieldContent('content'); ?>





  



  
  <script src="assets/jquery/jquery.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>



    <!-- Optional JavaScript; choose one of the two! -->
    <script
      src="https://code.jquery.com/jquery-3.6.1.min.js"
      integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ="
      crossorigin="anonymous"
    ></script>
    <script src="assets/script.js"></script>


    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>
<?php /**PATH C:\xampp\htdocs\project\project02\example-app\resources\views/layouts/frontend/master.blade.php ENDPATH**/ ?>